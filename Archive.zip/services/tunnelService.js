const { exec } = require('child_process');
const { promisify } = require('util');
const fs = require('fs');
const path = require('path');

const execAsync = promisify(exec);

/**
 * Check if cloudflared is installed
 */
async function isInstalled() {
  try {
    await execAsync('which cloudflared');
    return true;
  } catch {
    return false;
  }
}

/**
 * Get tunnel status
 */
async function getStatus() {
  try {
    const installed = await isInstalled();
    if (!installed) return { installed: false, running: false, tunnels: [] };

    // Check if tunnel service is running
    let running = false;
    try {
      const { stdout } = await execAsync('pgrep -f cloudflared');
      running = stdout.trim().length > 0;
    } catch { running = false; }

    // List tunnels
    let tunnels = [];
    try {
      const { stdout } = await execAsync('cloudflared tunnel list --output json 2>/dev/null');
      tunnels = JSON.parse(stdout || '[]');
    } catch { tunnels = []; }

    return { installed: true, running, tunnels };
  } catch {
    return { installed: false, running: false, tunnels: [] };
  }
}

/**
 * Get or create config file
 */
function getConfigPath() {
  const homeDir = require('os').homedir();
  return path.join(homeDir, '.cloudflared', 'config.yml');
}

function getConfig() {
  const configPath = getConfigPath();
  if (fs.existsSync(configPath)) {
    return fs.readFileSync(configPath, 'utf8');
  }
  return '';
}

function saveConfig(content) {
  const configPath = getConfigPath();
  const dir = path.dirname(configPath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(configPath, content, 'utf8');
}

/**
 * Start tunnel
 */
async function startTunnel() {
  try {
    const config = getConfig();
    if (!config) throw new Error('No config file found. Please configure first.');

    // Check if already running
    try {
      const { stdout } = await execAsync('pgrep -f "cloudflared tunnel run"');
      if (stdout.trim()) return 'Tunnel already running';
    } catch {}

    const { spawn } = require('child_process');
    const child = spawn('cloudflared', ['tunnel', '--config', getConfigPath(), 'run'], {
      detached: true,
      stdio: 'ignore'
    });
    child.unref();

    return 'Tunnel started';
  } catch (err) {
    throw new Error('Failed to start tunnel: ' + err.message);
  }
}

/**
 * Stop tunnel service
 */
async function stopTunnel() {
  try {
    await execAsync('pkill -f "cloudflared tunnel" || true');
    return 'Tunnel stopped';
  } catch {
    return 'No tunnel process found';
  }
}

module.exports = {
  isInstalled,
  getStatus,
  getConfig,
  saveConfig,
  getConfigPath,
  startTunnel,
  stopTunnel
};
